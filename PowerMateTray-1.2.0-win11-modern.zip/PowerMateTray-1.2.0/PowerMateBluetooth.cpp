
#include "stdafx.h"

#include <stdio.h>
#include <malloc.h>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <algorithm>

#include <objbase.h>
#include <windows.h>

#include <setupapi.h>
#pragma comment(lib, "setupapi")

#include <bluetoothleapis.h>
#pragma comment(lib, "bluetoothapis")

#include "Config.h"
#include "Actions.h"
#include "Volume.h"

// Griffin PowerMate BLE service/characteristics (as seen in BLE Explorer)
static const wchar_t* kGriffinServiceUuidStr = L"{25598CF7-4240-40A6-9910-080F19F91EBC}";
static const wchar_t* kRotationCharUuidStr   = L"{50F09CC9-FE1D-4C79-A962-B3A7CD3E5584}"; // handle ~36
static const wchar_t* kHoldCharUuidStr       = L"{9CF53570-DDD9-47F3-BA63-09ACEFC60415}"; // handle ~43
static const wchar_t* kLedCharUuidStr        = L"{C5CF8AE4-6988-409F-9EC4-F9DAA9147D15}"; // handle ~47

static std::atomic<bool> g_running(false);
static std::atomic<bool> g_connected(false);

static HANDLE g_device = INVALID_HANDLE_VALUE;

static PowerMateConfig g_cfg;

static BLUETOOTH_GATT_SERVICE g_service{};
static bool g_hasService = false;

static BTH_LE_GATT_CHARACTERISTIC g_rotationChar{};
static bool g_hasRotation = false;

static BTH_LE_GATT_CHARACTERISTIC g_holdChar{};
static bool g_hasHold = false;

static BTH_LE_GATT_CHARACTERISTIC g_ledChar{};
static bool g_hasLed = false;

static std::thread g_workerThread;
static std::thread g_ledThread;

static bool ContainsI(const std::wstring& hay, const std::wstring& needle)
{
	if (needle.empty()) return true;
	std::wstring a = hay, b = needle;
	std::transform(a.begin(), a.end(), a.begin(), towlower);
	std::transform(b.begin(), b.end(), b.begin(), towlower);
	return a.find(b) != std::wstring::npos;
}

static std::wstring GuidToString(const GUID& g)
{
	wchar_t buf[64]{0};
	StringFromGUID2(g, buf, (int)std::size(buf));
	return buf;
}

static bool ParseGuid(const wchar_t* s, GUID* out)
{
	return SUCCEEDED(CLSIDFromString(s, out));
}

static HANDLE OpenBluetoothDeviceByName(const GUID* interfaceGUID, const std::wstring& nameContains)
{
	HDEVINFO hDevInfo = SetupDiGetClassDevs(interfaceGUID, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);
	if (hDevInfo == INVALID_HANDLE_VALUE)
		return INVALID_HANDLE_VALUE;

	SP_DEVICE_INTERFACE_DATA deviceInterfaceData{};
	deviceInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

	for (DWORD devInterfaceIndex = 0; SetupDiEnumDeviceInterfaces(hDevInfo, NULL, interfaceGUID, devInterfaceIndex, &deviceInterfaceData); ++devInterfaceIndex)
	{
		DWORD required = 0;
		SetupDiGetDeviceInterfaceDetail(hDevInfo, &deviceInterfaceData, NULL, 0, &required, NULL);
		if (required == 0)
			continue;

		std::vector<uint8_t> buf(required);
		auto detail = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA*>(buf.data());
		detail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

		SP_DEVINFO_DATA devInfo{};
		devInfo.cbSize = sizeof(SP_DEVINFO_DATA);

		if (!SetupDiGetDeviceInterfaceDetail(hDevInfo, &deviceInterfaceData, detail, required, NULL, &devInfo))
			continue;

		wchar_t friendly[256]{0};
		if (!SetupDiGetDeviceRegistryPropertyW(hDevInfo, &devInfo, SPDRP_FRIENDLYNAME, NULL, (PBYTE)friendly, sizeof(friendly), NULL))
		{
			// fallback
			SetupDiGetDeviceRegistryPropertyW(hDevInfo, &devInfo, SPDRP_DEVICEDESC, NULL, (PBYTE)friendly, sizeof(friendly), NULL);
		}

		std::wstring fname = friendly;
		if (!ContainsI(fname, nameContains))
		{
			continue;
		}

		HANDLE h = CreateFile(detail->DevicePath, GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, NULL);

		if (h != INVALID_HANDLE_VALUE)
		{
			OutputDebugFormat("PowerMate: opened device interface: %S\n", detail->DevicePath);
			SetupDiDestroyDeviceInfoList(hDevInfo);
			return h;
		}
	}

	SetupDiDestroyDeviceInfoList(hDevInfo);
	return INVALID_HANDLE_VALUE;
}

static bool LoadServiceAndCharacteristics()
{
	g_hasService = g_hasRotation = g_hasHold = g_hasLed = false;

	// Services
	USHORT serviceCount = 0;
	auto hr = BluetoothGATTGetServices(g_device, 0, NULL, &serviceCount, BLUETOOTH_GATT_FLAG_NONE);
	if (hr != HRESULT_FROM_WIN32(ERROR_MORE_DATA) && FAILED(hr))
	{
		OutputDebugFormat("PowerMate: BluetoothGATTGetServices failed (count): 0x%x\n", hr);
		return false;
	}
	if (serviceCount == 0) return false;

	std::vector<BTH_LE_GATT_SERVICE> services(serviceCount);
	hr = BluetoothGATTGetServices(g_device, serviceCount, services.data(), &serviceCount, BLUETOOTH_GATT_FLAG_NONE);
	if (FAILED(hr))
	{
		OutputDebugFormat("PowerMate: BluetoothGATTGetServices failed: 0x%x\n", hr);
		return false;
	}

	GUID serviceGuid{};
	ParseGuid(kGriffinServiceUuidStr, &serviceGuid);

	for (auto& s : services)
	{
		if (IsEqualGUID(s.ServiceUuid.Value.LongUuid, serviceGuid))
		{
			g_service = s;
			g_hasService = true;
			break;
		}
	}
	if (!g_hasService)
	{
		OutputDebugFormat("PowerMate: Griffin service not found.\n");
		return false;
	}

	// Characteristics
	USHORT charCount = 0;
	hr = BluetoothGATTGetCharacteristics(g_device, &g_service, 0, NULL, &charCount, BLUETOOTH_GATT_FLAG_NONE);
	if (hr != HRESULT_FROM_WIN32(ERROR_MORE_DATA) && FAILED(hr))
	{
		OutputDebugFormat("PowerMate: GetCharacteristics count failed: 0x%x\n", hr);
		return false;
	}
	if (charCount == 0) return false;

	std::vector<BTH_LE_GATT_CHARACTERISTIC> chars(charCount);
	hr = BluetoothGATTGetCharacteristics(g_device, &g_service, charCount, chars.data(), &charCount, BLUETOOTH_GATT_FLAG_NONE);
	if (FAILED(hr))
	{
		OutputDebugFormat("PowerMate: GetCharacteristics failed: 0x%x\n", hr);
		return false;
	}

	GUID rotGuid{}, holdGuid{}, ledGuid{};
	ParseGuid(kRotationCharUuidStr, &rotGuid);
	ParseGuid(kHoldCharUuidStr, &holdGuid);
	ParseGuid(kLedCharUuidStr, &ledGuid);

	for (auto& c : chars)
	{
		auto id = c.CharacteristicUuid.Value.LongUuid;
		if (IsEqualGUID(id, rotGuid)) { g_rotationChar = c; g_hasRotation = true; }
		else if (IsEqualGUID(id, holdGuid)) { g_holdChar = c; g_hasHold = true; }
		else if (IsEqualGUID(id, ledGuid)) { g_ledChar = c; g_hasLed = true; }
	}

	OutputDebugFormat("PowerMate: characteristics found: rotation=%d hold=%d led=%d\n",
		g_hasRotation ? 1 : 0, g_hasHold ? 1 : 0, g_hasLed ? 1 : 0);

	return g_hasRotation || g_hasHold;
}

static bool ReadByteCharacteristic(const BTH_LE_GATT_CHARACTERISTIC& ch, uint8_t* outByte)
{
	if (g_device == INVALID_HANDLE_VALUE) return false;
	USHORT valueSize = 0;
	auto hr = BluetoothGATTGetCharacteristicValue(g_device, &ch, 0, NULL, &valueSize, BLUETOOTH_GATT_FLAG_NONE);
	if (hr != HRESULT_FROM_WIN32(ERROR_MORE_DATA) && FAILED(hr))
	{
		return false;
	}
	if (valueSize == 0) return false;

	std::vector<uint8_t> buf(valueSize);
	auto val = reinterpret_cast<PBLUETOOTH_GATT_VALUE>(buf.data());
	hr = BluetoothGATTGetCharacteristicValue(g_device, &ch, valueSize, val, &valueSize, BLUETOOTH_GATT_FLAG_NONE);
	if (FAILED(hr) || val->DataSize < 1)
	{
		return false;
	}

	*outByte = val->Data[0];
	return true;
}

static bool WriteCharacteristicBytes(const BTH_LE_GATT_CHARACTERISTIC& ch, const std::vector<uint8_t>& bytes)
{
	if (g_device == INVALID_HANDLE_VALUE) return false;
	if (bytes.empty()) return false;

	// BLUETOOTH_GATT_VALUE is variable-length; allocate enough for header + data
	size_t allocSize = sizeof(BLUETOOTH_GATT_VALUE) + bytes.size();
	auto mem = std::vector<uint8_t>(allocSize);
	auto val = reinterpret_cast<PBLUETOOTH_GATT_VALUE>(mem.data());
	val->DataSize = (USHORT)bytes.size();
	memcpy(val->Data, bytes.data(), bytes.size());

	auto hr = BluetoothGATTSetCharacteristicValue(g_device, &ch, val, NULL, BLUETOOTH_GATT_FLAG_NONE);
	if (FAILED(hr))
	{
		OutputDebugFormat("PowerMate: LED write failed: 0x%x\n", hr);
		return false;
	}
	return true;
}

static bool InCodes(int v, const std::vector<int>& codes)
{
	for (auto c : codes) if (c == v) return true;
	return false;
}

static void PollLoop()
{
	uint8_t lastRot = 0xFF;
	uint8_t lastHold = 0xFF;

	bool pressed = false;
	ULONGLONG pressStart = 0;

	while (g_running)
	{
		if (!g_connected)
		{
			Sleep(g_cfg.reconnectIntervalMs);
			continue;
		}

		// rotation
		if (g_hasRotation)
		{
			uint8_t v = 0;
			if (ReadByteCharacteristic(g_rotationChar, &v))
			{
				if (v != lastRot)
				{
					lastRot = v;
					int iv = (int)v;

					// Heuristic: if button held, map to hold-rotate actions
					if (pressed)
					{
						if (InCodes(iv, g_cfg.rotateLeftCodes) || iv < 64)
							DoAction(g_cfg.actionHoldRotateLeft);
						else if (InCodes(iv, g_cfg.rotateRightCodes) || iv > 64)
							DoAction(g_cfg.actionHoldRotateRight);
						else
							OutputDebugFormat("PowerMate: unknown pressed-rotate code=%d\n", iv);
					}
					else
					{
						if (InCodes(iv, g_cfg.rotateLeftCodes) || iv < 64)
							DoAction(g_cfg.actionRotateLeft);
						else if (InCodes(iv, g_cfg.rotateRightCodes) || iv > 64)
							DoAction(g_cfg.actionRotateRight);
						else
							OutputDebugFormat("PowerMate: unknown rotate code=%d\n", iv);
					}
				}
			}
		}

		// hold/button
		if (g_hasHold)
		{
			uint8_t v = 0;
			if (ReadByteCharacteristic(g_holdChar, &v))
			{
				if (v != lastHold)
				{
					lastHold = v;
					// Observed: value increments while held. Treat >65 as "pressed".
					bool nowPressed = (v > 65);
					if (nowPressed && !pressed)
					{
						pressed = true;
						pressStart = GetTickCount64();
					}
					else if (!nowPressed && pressed)
					{
						pressed = false;
						ULONGLONG duration = GetTickCount64() - pressStart;
						bool isLong = duration >= (ULONGLONG)g_cfg.longPressMs;

						if (isLong)
						{
							DoAction(g_cfg.actionPressLong);
							if (g_cfg.pressActionAlsoOnLongPress)
								DoAction(g_cfg.actionPressShort);
						}
						else
						{
							DoAction(g_cfg.actionPressShort);
						}
					}
				}
			}
		}

		Sleep(g_cfg.pollIntervalMs);
	}
}

static void LedLoop()
{
	// Only run if payloads are provided
	if (g_cfg.ledMutedPayloadHex.empty() && g_cfg.ledUnmutedPayloadHex.empty())
		return;

	bool lastMute = false;
	bool haveLast = false;

	auto mutedPayload = ParseHexBytes(g_cfg.ledMutedPayloadHex);
	auto unmutedPayload = ParseHexBytes(g_cfg.ledUnmutedPayloadHex);

	while (g_running)
	{
		if (!g_connected || !g_hasLed)
		{
			Sleep(500);
			continue;
		}

		bool muted = IsMuted();
		if (!haveLast || muted != lastMute)
		{
			haveLast = true;
			lastMute = muted;

			if (muted && !mutedPayload.empty())
			{
				OutputDebugFormat("PowerMate: LED -> muted\n");
				WriteCharacteristicBytes(g_ledChar, mutedPayload);
			}
			else if (!muted && !unmutedPayload.empty())
			{
				OutputDebugFormat("PowerMate: LED -> unmuted\n");
				WriteCharacteristicBytes(g_ledChar, unmutedPayload);
			}
		}

		Sleep(g_cfg.ledPollMs);
	}
}

static void ConnectLoop()
{
	GUID interfaceGuid{};
	ParseGuid(kGriffinServiceUuidStr, &interfaceGuid);

	while (g_running)
	{
		if (g_device == INVALID_HANDLE_VALUE)
		{
			HANDLE h = OpenBluetoothDeviceByName(&interfaceGuid, g_cfg.deviceNameContains);
			if (h != INVALID_HANDLE_VALUE)
			{
				g_device = h;
				if (LoadServiceAndCharacteristics())
				{
					g_connected = true;
					OutputDebugFormat("PowerMate: connected\n");
				}
				else
				{
					CloseHandle(g_device);
					g_device = INVALID_HANDLE_VALUE;
					g_connected = false;
				}
			}
			else
			{
				g_connected = false;
				Sleep(g_cfg.reconnectIntervalMs);
			}
		}
		else
		{
			// Device handle exists; assume connected unless reads start failing (poller will cope).
			Sleep(500);
		}
	}
}

void StartupPowerMateBluetooth()
{
	g_cfg = LoadPowerMateConfig();

	g_running = true;
	g_connected = false;

	g_workerThread = std::thread([]() {
		ConnectLoop();
	});

	// Start poll loop
	std::thread poller(PollLoop);
	poller.detach();

	// Start LED loop
	g_ledThread = std::thread(LedLoop);
}

void ShutdownPowerMateBluetooth()
{
	g_running = false;
	g_connected = false;

	if (g_workerThread.joinable())
		g_workerThread.join();

	if (g_ledThread.joinable())
		g_ledThread.join();

	if (g_device != INVALID_HANDLE_VALUE)
	{
		CloseHandle(g_device);
		g_device = INVALID_HANDLE_VALUE;
	}
}
