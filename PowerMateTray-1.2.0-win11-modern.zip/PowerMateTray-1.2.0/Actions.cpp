#include "stdafx.h"
#include "Actions.h"
#include "Volume.h"
#include <windows.h>

static void SendMediaKey(WORD vk)
{
    INPUT inputs[2]{};
    inputs[0].type = INPUT_KEYBOARD;
    inputs[0].ki.wVk = vk;
    inputs[1].type = INPUT_KEYBOARD;
    inputs[1].ki.wVk = vk;
    inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(2, inputs, sizeof(INPUT));
}

void DoAction(const std::wstring& actionName)
{
    if (actionName.empty() || actionName == L"None") return;

    if (actionName == L"VolumeUp") { IncreaseVolume(); return; }
    if (actionName == L"VolumeDown") { DecreaseVolume(); return; }
    if (actionName == L"Mute") { ToggleMute(); return; }

    if (actionName == L"PlayPause") { SendMediaKey(VK_MEDIA_PLAY_PAUSE); return; }
    if (actionName == L"NextTrack") { SendMediaKey(VK_MEDIA_NEXT_TRACK); return; }
    if (actionName == L"PrevTrack") { SendMediaKey(VK_MEDIA_PREV_TRACK); return; }
    if (actionName == L"Stop") { SendMediaKey(VK_MEDIA_STOP); return; }
}
