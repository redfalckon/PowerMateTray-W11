#pragma once
#include <string>
#include <vector>

struct PowerMateConfig
{
    std::wstring deviceNameContains = L"PowerMate";
    int pollIntervalMs = 20;
    int reconnectIntervalMs = 2000;

    // Press behavior
    int longPressMs = 650;
    bool pressActionAlsoOnLongPress = false; // if true, both short+long fire; default false.

    // Event code mapping (optional; used for notification mode and polling heuristics)
    std::vector<int> rotateLeftCodes  = { 103, 63 };
    std::vector<int> rotateRightCodes = { 104, 65 };

    // Actions
    std::wstring actionRotateLeft = L"VolumeDown";
    std::wstring actionRotateRight = L"VolumeUp";
    std::wstring actionPressShort = L"PlayPause";
    std::wstring actionPressLong = L"Mute";
    std::wstring actionHoldRotateLeft = L"PrevTrack";
    std::wstring actionHoldRotateRight = L"NextTrack";

    // LED status (hex payloads written to LED characteristic). Leave blank to disable.
    std::wstring ledMutedPayloadHex = L"";
    std::wstring ledUnmutedPayloadHex = L"";
    int ledPollMs = 250;
};

PowerMateConfig LoadPowerMateConfig();
void EnsureDefaultConfigExists();
std::vector<uint8_t> ParseHexBytes(const std::wstring& hex);
bool StringEqualsI(const std::wstring& a, const std::wstring& b);
