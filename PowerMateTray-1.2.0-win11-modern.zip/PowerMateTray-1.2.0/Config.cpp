#include "stdafx.h"
#include "Config.h"

#include <windows.h>
#include <shlobj.h>
#include <algorithm>
#include <sstream>

static std::wstring GetAppDataIniPath()
{
    PWSTR appData = nullptr;
    std::wstring ini;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, NULL, &appData)))
    {
        ini = std::wstring(appData) + L"\\PowerMateTray";
        CoTaskMemFree(appData);
    }
    else
    {
        ini = L".";
    }

    CreateDirectoryW(ini.c_str(), NULL);
    ini += L"\\powermate.ini";
    return ini;
}

static std::wstring GetProfileString(const std::wstring& section, const std::wstring& key, const std::wstring& def)
{
    wchar_t buf[2048]{0};
    GetPrivateProfileStringW(section.c_str(), key.c_str(), def.c_str(), buf, (DWORD)std::size(buf), GetAppDataIniPath().c_str());
    return std::wstring(buf);
}

static int GetProfileInt(const std::wstring& section, const std::wstring& key, int def)
{
    return GetPrivateProfileIntW(section.c_str(), key.c_str(), def, GetAppDataIniPath().c_str());
}

static std::vector<int> ParseCsvInts(const std::wstring& s)
{
    std::vector<int> out;
    std::wstringstream ss(s);
    std::wstring item;
    while (std::getline(ss, item, L','))
    {
        item.erase(std::remove_if(item.begin(), item.end(), iswspace), item.end());
        if (item.empty()) continue;
        try { out.push_back(std::stoi(item)); } catch(...) {}
    }
    return out;
}

bool StringEqualsI(const std::wstring& a, const std::wstring& b)
{
    if (a.size() != b.size()) return false;
    for (size_t i=0;i<a.size();++i)
    {
        if (towlower(a[i]) != towlower(b[i])) return false;
    }
    return true;
}

std::vector<uint8_t> ParseHexBytes(const std::wstring& hex)
{
    std::vector<uint8_t> bytes;
    std::wstring s;
    for (wchar_t c : hex)
    {
        if (iswxdigit(c)) s.push_back(c);
    }
    if (s.size() % 2 != 0) return bytes;

    for (size_t i=0;i<s.size(); i+=2)
    {
        wchar_t hi = s[i], lo = s[i+1];
        auto val = [](wchar_t ch)->int{
            ch = towlower(ch);
            if (ch >= L'0' && ch <= L'9') return ch - L'0';
            if (ch >= L'a' && ch <= L'f') return 10 + (ch - L'a');
            return 0;
        };
        int b = (val(hi) << 4) | val(lo);
        bytes.push_back((uint8_t)b);
    }
    return bytes;
}

void EnsureDefaultConfigExists()
{
    auto ini = GetAppDataIniPath();
    DWORD attrs = GetFileAttributesW(ini.c_str());
    if (attrs != INVALID_FILE_ATTRIBUTES) return;

    // Create default config
    WritePrivateProfileStringW(L"settings", L"DeviceNameContains", L"PowerMate", ini.c_str());
    WritePrivateProfileStringW(L"settings", L"PollIntervalMs", L"20", ini.c_str());
    WritePrivateProfileStringW(L"settings", L"ReconnectIntervalMs", L"2000", ini.c_str());
    WritePrivateProfileStringW(L"settings", L"LongPressMs", L"650", ini.c_str());
    WritePrivateProfileStringW(L"settings", L"PressActionAlsoOnLongPress", L"0", ini.c_str());

    WritePrivateProfileStringW(L"actions", L"RotateLeft", L"VolumeDown", ini.c_str());
    WritePrivateProfileStringW(L"actions", L"RotateRight", L"VolumeUp", ini.c_str());
    WritePrivateProfileStringW(L"actions", L"PressShort", L"PlayPause", ini.c_str());
    WritePrivateProfileStringW(L"actions", L"PressLong", L"Mute", ini.c_str());
    WritePrivateProfileStringW(L"actions", L"HoldRotateLeft", L"PrevTrack", ini.c_str());
    WritePrivateProfileStringW(L"actions", L"HoldRotateRight", L"NextTrack", ini.c_str());

    WritePrivateProfileStringW(L"codes", L"RotateLeft", L"103,63", ini.c_str());
    WritePrivateProfileStringW(L"codes", L"RotateRight", L"104,65", ini.c_str());

    WritePrivateProfileStringW(L"led", L"MutedPayloadHex", L"", ini.c_str());
    WritePrivateProfileStringW(L"led", L"UnmutedPayloadHex", L"", ini.c_str());
    WritePrivateProfileStringW(L"led", L"PollMs", L"250", ini.c_str());
}

PowerMateConfig LoadPowerMateConfig()
{
    EnsureDefaultConfigExists();
    PowerMateConfig cfg;
    cfg.deviceNameContains = GetProfileString(L"settings", L"DeviceNameContains", cfg.deviceNameContains);
    cfg.pollIntervalMs = GetProfileInt(L"settings", L"PollIntervalMs", cfg.pollIntervalMs);
    cfg.reconnectIntervalMs = GetProfileInt(L"settings", L"ReconnectIntervalMs", cfg.reconnectIntervalMs);
    cfg.longPressMs = GetProfileInt(L"settings", L"LongPressMs", cfg.longPressMs);
    cfg.pressActionAlsoOnLongPress = GetProfileInt(L"settings", L"PressActionAlsoOnLongPress", 0) != 0;

    cfg.actionRotateLeft = GetProfileString(L"actions", L"RotateLeft", cfg.actionRotateLeft);
    cfg.actionRotateRight = GetProfileString(L"actions", L"RotateRight", cfg.actionRotateRight);
    cfg.actionPressShort = GetProfileString(L"actions", L"PressShort", cfg.actionPressShort);
    cfg.actionPressLong = GetProfileString(L"actions", L"PressLong", cfg.actionPressLong);
    cfg.actionHoldRotateLeft = GetProfileString(L"actions", L"HoldRotateLeft", cfg.actionHoldRotateLeft);
    cfg.actionHoldRotateRight = GetProfileString(L"actions", L"HoldRotateRight", cfg.actionHoldRotateRight);

    cfg.rotateLeftCodes = ParseCsvInts(GetProfileString(L"codes", L"RotateLeft", L"103,63"));
    cfg.rotateRightCodes = ParseCsvInts(GetProfileString(L"codes", L"RotateRight", L"104,65"));

    cfg.ledMutedPayloadHex = GetProfileString(L"led", L"MutedPayloadHex", L"");
    cfg.ledUnmutedPayloadHex = GetProfileString(L"led", L"UnmutedPayloadHex", L"");
    cfg.ledPollMs = GetProfileInt(L"led", L"PollMs", cfg.ledPollMs);

    return cfg;
}
