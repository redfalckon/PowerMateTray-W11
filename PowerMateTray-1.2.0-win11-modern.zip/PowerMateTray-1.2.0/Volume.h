#pragma once

void StartupVolume();
void ShutdownVolume();

void IncreaseVolume();
void DecreaseVolume();
void ToggleMute();

bool IsMuted();
void SetMuted(bool muted);
