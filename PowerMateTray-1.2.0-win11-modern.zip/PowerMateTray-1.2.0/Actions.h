#pragma once
#include <string>

void DoAction(const std::wstring& actionName);
