#include "stdafx.h"

#include <windows.h>
#include <commctrl.h>
#include <mmdeviceapi.h>
#include <endpointvolume.h>

#define SAFE_RELEASE(punk) \
              if ((punk) != NULL) \
                { (punk)->Release(); (punk) = NULL; }

static IAudioEndpointVolume* pAudioEndpointVolume = NULL;

void StartupVolume()
{
	HRESULT hr = S_OK;

	// Get enumerator for audio endpoint devices.
	IMMDeviceEnumerator* pEnumerator = NULL;
	hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_INPROC_SERVER, __uuidof(IMMDeviceEnumerator), (void**)&pEnumerator);

	// Get default audio-rendering device.
	IMMDevice* pDevice = NULL;
	hr = pEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice);

	// Activate to get the object
	hr = pDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_ALL, NULL, (void**)&pAudioEndpointVolume);

	SAFE_RELEASE(pEnumerator);
	SAFE_RELEASE(pDevice);
}

void ShutdownVolume()
{
	SAFE_RELEASE(pAudioEndpointVolume);
}

void IncreaseVolume()
{
	pAudioEndpointVolume->VolumeStepUp(nullptr);
}

void DecreaseVolume()
{
	pAudioEndpointVolume->VolumeStepDown(nullptr);
}

void ToggleMute()
{
	BOOL mute;
	pAudioEndpointVolume->GetMute(&mute);
	pAudioEndpointVolume->SetMute(!mute, NULL);
}



bool IsMuted()
{
	BOOL mute = FALSE;
	if (pAudioEndpointVolume)
	{
		pAudioEndpointVolume->GetMute(&mute);
	}
	return mute ? true : false;
}

void SetMuted(bool muted)
{
	if (pAudioEndpointVolume)
	{
		pAudioEndpointVolume->SetMute(muted ? TRUE : FALSE, NULL);
	}
}
